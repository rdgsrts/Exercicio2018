package model;

public class Modalidade extends Olimpiada {

	private String Nome;
}
